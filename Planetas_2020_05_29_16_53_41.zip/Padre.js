class Padre{
   constructor(){
      this.img=loadImage("planeta_4");
      }

   mostrar(){
    push();
    imageMode(CENTER);
    pop(); 
        }
}