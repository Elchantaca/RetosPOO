var Fast;
var Hill;
var Song;
var Egg;

function preload(){
  Song=loadSound("Eggman.mp3")//Cancion (Eggman Theme Movie fanmade)
  Hill=loadImage("Hill.jpg");//Fondo
}

function setup() {
  createCanvas(600, 500);
  frameRate(50);
  Egg=new Eggman();//Personaje Huevon
  Fast=new Sonic();//Personaje rapido 
  Song.play();//Cancion comienza
}

function draw() {
  background(0);
  image(Hill,0,0,600,600);//Fondo del juego
  Fast.mostrar();
  if(keyCode==68){//Mover a la derecha con tecla d
    Fast.derecha()}
  if(keyCode==65){//Mover a la izquierda con tecla a
    Fast.izquierda()}
  Egg.demostrar();
  if(keyCode==76){//Mover a la derecha con tecla l
    Egg.derecho()}
  if(keyCode==74){//Mover a la izquierda con tecla j
    Egg.izquierdo()}
    if(keyCode==75){//Mover arriba con tecla i
    Egg.arriba()}
  if(keyCode==73){//Mover abajo con tecla k
    Egg.abajo()}

}