class Sonic{
  constructor(){
    //Posicion del personaje
    this.x = width/2;
    this.y = 350;
    this.dir=0.4;
    //velocidad en x
    this.velx=20;
    //Imagenes
    this.img=[]; //Array
    this.frame=0;
    for(var i=0; i<10;i++){
      this.img[i]=loadImage("Sonico/Sonico_"+i+".gif");
      }
    }
   mostrar(){
    push();
    translate(this.x, this.y);
    scale(this.dir, 0.4);
    imageMode(CENTER);
    image(this.img[this.frame],0,0 );
    pop(); 
        }
  derecha(){
    this.frame++;
    this.x = this.x + this.velx;
    this.dir = 0.5;
    if(this.frame > 9){
      this.frame = 0;
  }
  }
 izquierda(){
    this.frame++;
    this.x = this.x - this.velx;
    this.dir = -0.5;
    if(this.frame > 9){
      this.frame = 0;
  }
 }
  
}