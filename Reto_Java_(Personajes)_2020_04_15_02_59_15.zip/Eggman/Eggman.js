class Eggman{
  constructor(){
    //Posicion del personaje
    this.o = width/2;
    this.i = 150;
    this.dir=3.5;
    //velocidad en x
    this.velx=5;
    this.vely=4;
    //Imagenes
    this.img=[]; //Array
    this.frame=0;
    for(var i=0; i<4;i++){
      this.img[i]=loadImage("Eggman_"+i+".gif");
      }
    }
   demostrar(){
    translate(this.o, this.i);
    scale(this.dir,3.5);
    imageMode(CENTER);
    image(this.img[this.frame],0,0 );
        }
  derecho(){
    this.frame++;
    this.o = this.o + this.velx;
    this.dir = -3.5;
    if(this.frame > 3){
      this.frame = 0;
  }
  }
 izquierdo(){
    this.frame++;
    this.o = this.o - this.velx;
    this.dir = 3.5;
    if(this.frame > 3){
      this.frame = 0;
  }
 }
  arriba(){
    this.frame++;
    this.i=this.i+this.vely;
    if(this.frame>3){
      this.frame=0;
    }
  }
  abajo(){
    this.frame++;
    this.i=this.i-this.vely;
    if(this.frame>3){
      this.frame=0;
    }
  
}
}